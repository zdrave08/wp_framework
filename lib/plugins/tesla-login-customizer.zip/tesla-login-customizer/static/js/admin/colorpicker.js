/**
 * JS for admin colorpicker, included to Pages that has colorpicker
 */
(function( $ ) {

    // Add Color Picker to all inputs that have 'tt-colorpicker' class
    $(function() {
        $('.tt-colorpicker').wpColorPicker();
    });

})( jQuery );