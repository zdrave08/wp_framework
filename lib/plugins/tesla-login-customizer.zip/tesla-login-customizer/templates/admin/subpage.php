<?php
/**
 * Subpage example view
 */
?>
<div class="container">
    <h1>SubPage</h1>
    <p>Subpage content</p>
</div>